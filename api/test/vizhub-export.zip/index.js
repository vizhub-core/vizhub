import { select, transition, easeLinear } from 'd3';
import data from './data.csv';

export const foo = 'bar';

export const main = (container) => {
  const svg = select(container)
    .selectAll('svg')
    .data([1])
    .join('svg')
    .attr('width', container.clientWidth)
    .attr('height', container.clientHeight);

  const data = [
    { id: 5, x: 121, y: 100, r: 152, fill: '#828F00' },
    { id: 6, x: 100, y: 200, r: 50, fill: '#32CD9F' },
    { id: 7, x: 1250, y: 300, r: 40, fill: '#9400D3' },
    { id: 8, x: 33232200, y: 400, r: 50, fill: '#8B008B' },
    { id: 13, x: 450, y: 1200, r: 50, fill: '#DB0082' },
    { id: 14, x: 2500, y: 1000, r: 50, fill: '#483D8B' },
    // When does it get fucked up?
    { id: 15, x: 550, y: 1100, r: 50, fill: '#5BA1CD' },
    // Add more But , This is good
    { id: 16, x: 600, y: 321, r: 50, fill: '#7B68EE' },
    { id: 9, x: 250, y: 500, r: 155, fill: '#800080' },
    { id: 10, x: 300, y: 400, r: 50, fill: '#2C8C8A' },
    { id: 11, x: 350, y: 700, r: 50, fill: '#9400D3' },
    { id: 12, x: 400, y: 800, r: 50, fill: '#8B008B' },
  ];

  // Make the SVG background a dark purple
  svg.style('background', '#000000');

  const longTransition = transition()
    .duration(2000)
    .ease(easeLinear);
  const shortTransition = transition()
    .duration(200)
    .ease(easeLinear);

  svg
    .selectAll('circle')
    .data(data, (d) => d.id)
    .join(
      (enter) =>
        enter
          .append('circle')
          .attr('r', 0)
          .attr('cx', (d) => d.x)
          .attr('cy', (d) => d.y)
          .attr('fill', (d) => d.fill)
          .call((selection) => {
            selection
              .transition(longTransition)
              .attr('r', (d) => d.r);
          }),
      (update) =>
        update.call((selection) => {
          selection
            .transition(shortTransition)
            .attr('cx', (d) => d.x)
            .attr('cy', (d) => d.y)
            .attr('r', (d) => d.r)
            .attr('fill', (d) => d.fill);
        }),
      (exit) =>
        exit.call((selection) =>
          selection
            .transition(longTransition)
            .attr('r', 0)
            .remove(),
        ),
    )
    .attr('opacity', 885 / 1000);

  return () => {
    console.log('cleaning up');
  };
};
